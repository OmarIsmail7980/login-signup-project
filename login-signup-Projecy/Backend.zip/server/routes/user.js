const express = require("express");
const router = express();
const userModel = require("../db/schema/userSchema");
const jwt = require("jsonwebtoken")
const SECRET_KEY =  "sjkdhfsdkfhjkdshfjksdhf";

router.post("/register",async (req,res)=>{
    
    try{
        const body = req.body;
        
        const data =new userModel(body);
        const response = await data.save();
        console.log(response)
        res.json(response);

    }catch(error){
        res.status(500).send({status:"Error occured"})
    }
    

})

router.post("/login",async(req,res)=>{

    try{
        const body = req.body;

        const doc = userModel.findOne({body},"-password");
        if(doc){
            const token = jwt.sign({id:doc._id},SECRET_KEY,{expiresIn:3600})
            res.json({status:"success",message:"user is logged in",accessToken:token})
        }else{
            res.status(403).json({status:"failed",message:"user not found!"})
        }
    }catch(error){
        res.status(500).json({status:"failed",message:"error occured"})
    }
    
})

router.post("/whoami",async(req,res)=>{
    const {authorization} = req.header;
    try{
        
        const payload = jwt.verify(authorization, SECRET_KEY);
        if(payload){
            const user = await userModel.findOne({_id:payload.id},"-password");
            res.json({status:"success",data:user})
        }else{
            res.status(403).json({status:"failed",message:"user not found!"})
        }
    }catch(error){
        res.status(500).json({status:"failed",message:"error occured"})
    }
})

module.exports = router;