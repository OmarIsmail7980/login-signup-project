const express = require("express")
const cors = require("cors")
const router = require("./routes/user")

app = express();

const port = 8080;


require("./db/connect")
app.use(cors())
app.use(express.json());

app.use("/user",router)


app.listen(port,()=>{
    console.log("listening to port %d",port)
})

