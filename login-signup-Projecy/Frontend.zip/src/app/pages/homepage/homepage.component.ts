import { Component, OnInit } from '@angular/core';
import { LoginSignupService } from 'src/app/services/login-signup.service';

@Component({
  selector: 'log-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {

  constructor(private service:LoginSignupService) { }

  user:any[]=[];

  ngOnInit(): void {

    this.service.whoami().subscribe(response=>{
      console.log(response)
      this.user.push(response)
    })
  }



 

}
