import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators,FormControl } from '@angular/forms';
import { LoginSignupService } from 'src/app/services/login-signup.service';

@Component({
  selector: 'log-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  constructor(private service:LoginSignupService) { }

  signUpForm = new FormGroup({
    username:new FormControl("",[Validators.required]),
    firstName:new FormControl("",[Validators.required] ),
    lastName:new FormControl("",[Validators.required] ),
    email:new FormControl("",[Validators.required,Validators.email]),
    password:new FormControl("",[Validators.required])
  })

  ngOnInit(): void {
  }

  

  get username(){
    return this.signUpForm.get("username");
  }

  get firstName(){
    return this.signUpForm.get("firstName")
  }

  get lastName(){
    return this.signUpForm.get("lastName");
  }

  get email(){
    return this.signUpForm.get("email")
  }

  get password(){
    return this.signUpForm.get("password")
  }


  signUpAPI(){
    
    return this.service.signUp(this.signUpForm.value).subscribe(response=>{
      console.log(response);
      this.signUpForm.reset();
    })
  }

}
