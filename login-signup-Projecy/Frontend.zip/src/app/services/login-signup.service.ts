import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http"
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginSignupService {

  constructor(private http:HttpClient) { }

  user:BehaviorSubject<any> = new BehaviorSubject(null);

  signUp(form:any){
    return this.http.post("http://localhost:8080/user/register",form)
  }

  login(form:any){
    return this.http.post("http://localhost:8080/user/login",form)
  }

  whoami(){
    // let result;
    // if(window.localStorage.getItem("accessToken")){
    //   result = this.http.post("http://localhost:8080/user/whoami",{headers:
    //   {authorization:window.localStorage.getItem("accessToken") || ""}}).subscribe((response)=>{
    //     console.log(response)
    //   })
    // }
    return this.http.post("http://localhost:8080/user/whoami",{headers:
    {authorization:window.localStorage.getItem("accessToken") || ""}})
  }

  
}
