import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginSignupService } from 'src/app/services/login-signup.service';

@Component({
  selector: 'log-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  form={
    username:"",
    password:""
  }
  constructor(private loginServ:LoginSignupService, private router:Router) { }

  ngOnInit(): void {
  }

  loginAPI(form:any){
    return this.loginServ.login(form.value).subscribe((response:any)=>{
      console.log(response);
      window.localStorage.setItem("accessToken",response.accessToken)
      this.router.navigateByUrl("/")
    })
  }

}
