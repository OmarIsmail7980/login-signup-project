const {Schema, model} = require("mongoose");

userSchema = new Schema({
    username:String,
    firstName:String,
    lastName:String,
    email:String,
    password:String,
   dateCreated:{type:Date, default:Date.now()}
})

const userModel = model("users",userSchema,"users");

module.exports = userModel;